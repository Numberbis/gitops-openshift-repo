# Jupyter + Spark + Flink sur OpenShift

Instance JupyterLab déployée sur OpenShift pour tester des jobs **PySpark 3.5** et **PyFlink 1.20**, en mode local dans le pod (défaut), avec option Spark-on-K8s en mode client.

```
jupyter-spark-flink/
├── build/
│   ├── Dockerfile          # UBI9 python-311 + JDK 17 + PySpark + PyFlink
│   ├── requirements.txt    # versions épinglées
│   └── .gitlab-ci.yml      # build → Trivy (non bloquant) → push Artifactory
├── base/                   # Kustomize base (à référencer dans une Application ArgoCD)
│   ├── kustomization.yaml
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── service-headless-spark.yaml   # mode client Spark-on-K8s uniquement
│   ├── route.yaml
│   ├── pvc.yaml
│   ├── configmap-spark-defaults.yaml
│   ├── externalsecret-token.yaml     # token Jupyter depuis Vault via ESO
│   ├── serviceaccount.yaml
│   ├── role-spark.yaml               # mode client uniquement
│   └── rolebinding-spark.yaml
└── README.md
```

---

## 1. Choix de conception (et pourquoi)

| Décision | Justification |
|---|---|
| Base **UBI9 python-311** plutôt que `jupyter/pyspark-notebook` | Les images docker-stacks supposent UID 1000 fixe ; UBI est conçue pour l'UID arbitraire de la SCC `restricted-v2` (groupe 0). Python 3.11 est la **dernière** version supportée simultanément par PySpark 3.5 et PyFlink 1.20. |
| **JDK 17** (`-devel`, pas `-headless`) | Intersection des supports Spark 3.5 (8/11/17) et Flink 1.20 (11/17). Le paquet `-devel` est obligatoire : `pip install apache-flink` compile **pemja** (bridge JNI natif) et a besoin des headers JDK + gcc au build. C'est le piège n°1 de cette image. |
| Mode **`local[*]`** par défaut | Objectif = *tester* des jobs. Spark et Flink tournent entièrement dans le pod, aucun RBAC ni image executor nécessaire. Le mode client Spark-on-K8s est préparé mais commenté (validation par étapes). |
| `strategy: Recreate` | PVC en RWO ; un RollingUpdate créerait deux pods se disputant le volume. |
| Token via **ESO/Vault** | Aucun secret dans Git, cohérent avec le pattern `valuesFrom` déjà en place sur Grafana. |
| `emptyDir` 8 Gi sur `/tmp` | `spark.local.dir` (shuffle/spill) et le state backend Flink écrivent beaucoup ; sans sizeLimit, risque d'éviction du nœud. |

---

## 2. Méthode de build — pas à pas

### 2.1 Prérequis

- Podman (ou Docker) sur le poste, accès réseau vers `registry.access.redhat.com` et PyPI (ou le remote PyPI d'Artifactory — voir 2.5)
- Compte de service Artifactory avec droit `push` sur le repo Docker

### 2.2 Build local

```bash
cd jupyter-spark-flink/build

podman build --format docker \
  -f Dockerfile \
  -t jupyter-spark-flink:1.0.0 .
```

Points d'attention pendant le build :

1. **Étape dnf** : vérifier que `java-17-openjdk-devel` s'installe bien (≈300 Mo). Si le proxy d'entreprise bloque les repos UBI, ajouter `--build-arg` ou monter un `ubi.repo` interne.
2. **Étape pip** : la compilation de `pemja` prend 1–2 min et échoue avec `Java home not found` si `JAVA_HOME` n'est pas défini **avant** le `pip install` — c'est pour ça que le `ENV JAVA_HOME` précède le `COPY requirements.txt` dans le Dockerfile. Ne pas réordonner.
3. **Taille finale** : ~3,5–4 Go (JDK + Spark + Flink embarqués dans les wheels). Normal.

### 2.3 Test local avant push

```bash
podman run --rm -p 8888:8888 \
  -e JUPYTER_TOKEN=test \
  --user 1000770000:0 \
  jupyter-spark-flink:1.0.0
```

Le `--user <uid-aléatoire>:0` **simule le comportement OpenShift** : si Jupyter démarre et écrit dans son répertoire avec cet UID, l'image passera la SCC `restricted-v2`. C'est le test qui évite 90 % des `CrashLoopBackOff` au premier déploiement.

Ouvrir `http://localhost:8888/?token=test` et exécuter les deux cellules de validation (§4).

### 2.4 Tag + push Artifactory

```bash
podman login artifactory.example.local
podman tag jupyter-spark-flink:1.0.0 \
  artifactory.example.local/docker-local/data/jupyter-spark-flink:1.0.0
podman push artifactory.example.local/docker-local/data/jupyter-spark-flink:1.0.0
```

Rappel : `podman tag` ne duplique rien, c'est une référence supplémentaire sur le même Image ID.

### 2.5 Build via GitLab CI (recommandé)

Le `.gitlab-ci.yml` fourni suit le pattern du pipeline Docker existant :

1. **build** (buildah rootless) — déclenché sur **tag git** (`1.0.0`), l'image est exportée en `oci-archive` comme artefact de job
2. **scan** — Trivy en `allow_failure: true` (non bloquant, comme convenu tant que les cycles de maintenance ne sont pas terminés), rapport SARIF archivé 30 j
3. **push** — login + push vers Artifactory uniquement si build + pipeline OK

Variables CI à créer (masked) : `ARTIFACTORY_REGISTRY`, `ARTIFACTORY_REPO`, `ARTIFACTORY_USER`, `ARTIFACTORY_TOKEN`.

Si les runners n'ont pas d'accès PyPI direct, ajouter dans le Dockerfile :
```dockerfile
ARG PIP_INDEX_URL=https://artifactory.example.local/artifactory/api/pypi/pypi-remote/simple
ENV PIP_INDEX_URL=$PIP_INDEX_URL
```

---

## 3. Déploiement

### 3.1 Pré-déploiement

1. Créer le secret dans Vault : `secret/data-platform/jupyter` avec une clé `token` (valeur : `openssl rand -hex 32`)
2. Adapter dans `base/kustomization.yaml` : le namespace, le registry/tag de l'image
3. Adapter `externalsecret-token.yaml` au nom réel du (Cluster)SecretStore
4. Si pull authentifié sur Artifactory : décommenter `imagePullSecrets` dans `serviceaccount.yaml` et créer l'ExternalSecret correspondant (type `kubernetes.io/dockerconfigjson`)

### 3.2 Via ArgoCD (manuel sync, conformément au tier actuel)

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: jupyter-spark-flink
  namespace: openshift-gitops
spec:
  project: default
  source:
    repoURL: https://gitlab.example.local/infra/jupyter-spark-flink.git
    targetRevision: main
    path: base
  destination:
    server: https://kubernetes.default.svc
    namespace: jupyter-lab
  syncPolicy:
    syncOptions:
      - CreateNamespace=false
    # pas d'automated : sync manuel, selfHeal off
```

Ou en direct pour un premier test : `oc apply -k base/`

### 3.3 Vérifications

```bash
oc get externalsecret jupyter-token   # SecretSynced=True
oc rollout status deploy/jupyter
oc get route jupyter -o jsonpath='{.spec.host}'
```

---

## 4. Validation Spark & Flink dans le notebook

**PySpark (local) :**
```python
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("smoke-test").getOrCreate()
spark.range(1_000_000).selectExpr("sum(id)").show()
# UI Spark : port-forward 4040 ou Route dédiée
```

**PyFlink (mini-cluster local) :**
```python
from pyflink.table import TableEnvironment, EnvironmentSettings
t_env = TableEnvironment.create(EnvironmentSettings.in_batch_mode())
t_env.execute_sql("""
  CREATE TABLE gen (id BIGINT) WITH ('connector'='datagen','number-of-rows'='1000000')
""")
t_env.execute_sql("SELECT COUNT(*), SUM(id) FROM gen").print()
```

**Kafka depuis Flink** : ajouter le connecteur en tête de notebook :
```python
t_env.get_config().set("pipeline.jars",
  "file:///opt/app-root/src/notebooks/jars/flink-sql-connector-kafka-3.3.0-1.20.jar")
```
(déposer le jar sur le PVC ; le télécharger depuis le remote Maven d'Artifactory)

---

## 5. Passage au mode client Spark-on-K8s (étape suivante)

Quand le mode local ne suffit plus (volumétrie), dans l'ordre :

1. Vérifier que `role-spark.yaml` / `rolebinding-spark.yaml` sont bien synchés
2. Construire/pousser une image **executor** Spark 3.5 (image officielle `apache/spark:3.5.x` retaguée dans Artifactory — même version exacte que le pyspark du notebook, sinon incompatibilité de sérialisation)
3. Décommenter le bloc `k8s://` dans `configmap-spark-defaults.yaml` — le `spark.driver.host` pointe sur le service headless `jupyter-spark-driver`, ports driver/blockManager fixés à 7078/7079 (déjà exposés dans le Deployment)
4. Sync + redémarrage du pod, puis smoke test avec `spark.executor.instances=1`

Aucun EgressFirewall requis : tout le trafic (driver ↔ executors ↔ API server) reste interne au cluster.
