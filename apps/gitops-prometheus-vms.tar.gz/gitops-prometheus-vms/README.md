# gitops-prometheus-vms

Prometheus **dédié**, déployé en GitOps (ArgoCD + Kustomize), pour scraper les
métriques de VMs **hors du cluster OpenShift** pendant la migration.

Séparé du monitoring natif OpenShift : on ne mélange pas métriques de plateforme
et métriques d'infra legacy.

---

## Les deux pièges OpenShift (à comprendre avant de déployer)

**Piège 1 — l'operator natif d'OpenShift ne reconciliera pas ton Prometheus.**
Il ne surveille que ses propres namespaces (`openshift-monitoring`…). Un
`Prometheus` CR posé dans `monitoring-vms` resterait un YAML mort. → Il faut
**ton propre operator**, scopé à `monitoring-vms` via `--namespaces`.

**Piège 2 — ne pas réinstaller les CRDs.**
Les CRDs `monitoring.coreos.com` (`Prometheus`, `ScrapeConfig`…) sont des objets
**globaux**, déjà installés par OpenShift. Ton operator doit les **réutiliser**,
pas les réapporter — sinon il risque d'écraser celles d'OpenShift et de casser
le monitoring de tout le cluster. → Le kustomization de l'operator ne référence
**aucun** fichier CRD.

---

## Structure

```
base/
  operator/     -> l'operator scopé + RBAC (sync-wave 0). PAS de CRDs.
  prometheus/   -> Prometheus CR, SA de scrape, ScrapeConfig, ExternalSecret (wave 1)
overlays/prod/  -> IP réelles des VMs (patch) + assemblage
network/        -> EgressFirewall + EgressIP (joignabilité des VMs)
argocd/         -> Application ArgoCD (tier 1, sync manuel)
```

---

## Ordre de validation (NE PAS déployer à l'aveugle)

Avant tout déploiement, deux vérifs qui évitent de débugger dans le noir :

**1. La CRD ScrapeConfig existe-t-elle ?**
```bash
oc get crd scrapeconfigs.monitoring.coreos.com
```
- Présente → OK, on réutilise (piège 2 respecté).
- Absente → ta version d'operator OpenShift est trop ancienne. Deux options :
  apporter *uniquement* cette CRD, ou basculer le ScrapeConfig sur
  `additionalScrapeConfigs` (Secret de scrape brut, sans CRD).

**2. Les VMs sont-elles joignables depuis un pod ?** (avant même de déployer)
```bash
oc debug -n monitoring-vms --image=registry.access.redhat.com/ubi9/ubi-minimal -- \
  curl -s -o /dev/null -w '%{http_code}\n' http://10.20.30.11:9100/metrics
```
- `200` → réseau OK, il ne reste que le déclaratif.
- timeout/refused → problème EgressFirewall / EgressIP / firewall VM (voir
  `network/egress.yaml`). Même levier que ton accès Vault.

**3. Cohérence de version operator ↔ CRD**
```bash
oc get crd prometheuses.monitoring.coreos.com -o jsonpath='{.spec.versions[*].name}'
```
Épingle l'image de l'operator proche de cette version pour éviter que des champs
récents du `Prometheus` CR soient silencieusement ignorés.

---

## Déploiement

Rendu local pour relecture avant push :
```bash
kustomize build overlays/prod | less
```

Puis via ArgoCD (tier 1, sync manuel) :
```bash
oc apply -f argocd/application-prometheus-vms.yaml
# Synchronisation déclenchée À LA MAIN (pas d'auto-sync en tier 1)
argocd app sync prometheus-vms
```

---

## À personnaliser (checklist)

- [ ] `argocd/application-prometheus-vms.yaml` : `repoURL`, `targetRevision`, ns ArgoCD
- [ ] `base/operator/operator-deployment.yaml` : version d'image cohérente avec tes CRDs
- [ ] `base/prometheus/prometheus.yaml` : `storageClassName`, rétention, ressources
- [ ] `base/prometheus/externalsecret-scrape.yaml` : `secretStoreRef`, chemin Vault
- [ ] `overlays/prod/scrapeconfig-vms-patch.yaml` : IP réelles des VMs
- [ ] `network/egress.yaml` : subnets, IP egress à whitelister côté VMs

---

## Progression des tiers (rappel)

Tier 1 (ici) : sync manuel, drift visible.
Tier 2 : ajouter `syncPolicy.automated` (auto-sync).
Tier 3 : `automated.selfHeal: true` — une fois la confiance opérationnelle
acquise, par Application.
